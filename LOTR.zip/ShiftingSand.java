

/**
 * ShiftingSand a futohomoknak felel meg
 * A konstruktorban beallitott erteket alapjan lassitja az ellenfelet.
 * @author justice_league
 *
 */
public class ShiftingSand extends Barrier {

	public ShiftingSand() {
		/**
		 * ShiftingSand a futohomoknak felel meg
		 * A konstruktorban beallitott erteket alapjan lassitja az ellenfelet.
		 */
		System.out.println("ShiftingSand konstruktor");
	}

}