

/**
 * SmallTower a kisebb toronynak felel meg
 * A konstruktorban beallitott ertekek szerint tamadja az ellenfelet.
 * @author justice_league
 *
 */
public class SmallTower extends Tower {

	public SmallTower() {
		/**
		 * SmallTower a kisebb toronynak felel meg
		 * A konstruktorban beallitott ertekek szerint tamadja az ellenfelet.
		 */
		System.out.println("SmallTower konstruktor");
	}

}