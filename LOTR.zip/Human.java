

/**
 *Human osztaly az Enemy leszarmazottja, ember fajt kepviseli.
 *Az ellenfel tipusoknal ot vehetjuk kiindulasi alapnak.
 *Konstruktoraban definialjuk a valtozoinak erteket 
 * @author justice_league
 *
 */
public class Human extends Enemy {

	/**
	 *Human osztaly az Enemy leszarmazottja, ember fajt kepviseli.
	 *Az ellenfel tipusoknal ot vehetjuk kiindulasi alapnak.
	 *Konstruktoraban definialjuk a valtozoinak erteket
	 */
	public Human() {
		System.out.println("Human konstruktor - inicializalja az eleterot es a sebesseget");
	}

}