

/**
 * Dwarf - ellenfelek egy tipusa
 * torpenek felel meg
 * @author justice_league
 *
 */
public class Dwarf extends Enemy {

	/**
	 * Dwarf - ellenfelek egy tipusa
	 */
	public Dwarf() {
		System.out.println("Dwarf konstruktor");
	}

}