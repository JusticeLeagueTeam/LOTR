

/**
 * Hobbit - Ellenfelek egy fajtaja
 * @author justice_league
 *
 */
public class Hobbit extends Enemy {

	/**
	 * inicializalja az eleterot es a sebesseget
	 */
	public Hobbit() {
		System.out.println("Hobbit konstruktor - inicializalja az eleterot es a sebesseget");
	}

}