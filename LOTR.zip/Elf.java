

/**
 * Elf - ellenfelek egy tipusa
 * @author justice_league
 *
 */
public class Elf extends Enemy {
	/**
	 * Elf - ellenfelek egy tipusa
	 */
	public Elf() {
		System.out.println("Elf konstruktor - inicializalja az eleterot es a sebesseget");
	}

}