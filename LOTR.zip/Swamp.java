

/**
 * Swamp osztaly a mocsarnak felel meg
 * A konstrutorban beallitott ertek szerint lassitja az ellenfeleket
 * @author justice_league
 *
 */
public class Swamp extends Barrier {
	/**
	 * Swamp osztaly a mocsarnak felel meg
	 * A konstrutorban beallitott ertek szerint lassitja az ellenfeleket
	 */
	public Swamp() {
		System.out.println("Swamp konstruktor");
	}

}