

/**
 * BigTower - tornyok egy tipusa
 * nagyobb toronytipusnak felel meg
 * @author justice_league
 *
 */
public class BigTower extends Tower {
	/**
	 * BigTower konstruktor
	 */
	public BigTower() {
		System.out.println("BigTower konstruktor");
	}

}